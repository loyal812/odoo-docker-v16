# -*- coding: utf-8 -*-

from . import sale_order, stock_delivery_note, account_move, stock_picking
from . import sale  # noqa